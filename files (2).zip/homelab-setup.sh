#!/bin/bash

# Homelab Setup Script - Ubuntu + KVM
# For development + production VMs

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_step() { echo -e "${BLUE}[STEP]${NC} $1"; }

# Check root
if [[ $EUID -ne 0 ]]; then
    echo "Run with sudo"
    exit 1
fi

log_step "1/6 - Updating System"
apt update
apt upgrade -y

log_step "2/6 - Installing KVM/QEMU"
apt install -y \
    qemu-kvm \
    libvirt-daemon-system \
    libvirt-clients \
    bridge-utils \
    virt-manager \
    ovmf

log_step "3/6 - Installing Cockpit (Web UI for VM management)"
apt install -y cockpit cockpit-machines

log_step "4/6 - Installing Development Tools"
apt install -y \
    git \
    curl \
    wget \
    vim \
    build-essential \
    python3 \
    python3-pip \
    python3-venv \
    htop \
    net-tools

log_step "5/6 - Configuring KVM"

# Add user to groups
REAL_USER=${SUDO_USER:-$USER}
usermod -aG libvirt $REAL_USER
usermod -aG kvm $REAL_USER

# Enable services
systemctl enable libvirtd
systemctl start libvirtd
systemctl enable cockpit.socket
systemctl start cockpit.socket

# Configure VM storage pool
if [ -d "/vmstorage" ]; then
    log_info "Setting up VM storage at /vmstorage"
    mkdir -p /vmstorage/vms
    chown -R libvirt-qemu:kvm /vmstorage/vms
    
    # Create storage pool
    virsh pool-define-as vm-pool dir - - - - "/vmstorage/vms" 2>/dev/null || true
    virsh pool-build vm-pool 2>/dev/null || true
    virsh pool-start vm-pool 2>/dev/null || true
    virsh pool-autostart vm-pool 2>/dev/null || true
else
    log_info "Using default storage at /var/lib/libvirt/images"
fi

log_step "6/6 - Configuring Network Bridge (for VMs)"
# Create bridge network for VMs
cat > /tmp/bridge.xml << 'EOF'
<network>
  <name>br0</name>
  <forward mode='nat'>
    <nat>
      <port start='1024' end='65535'/>
    </nat>
  </forward>
  <bridge name='br0' stp='on' delay='0'/>
  <ip address='192.168.100.1' netmask='255.255.255.0'>
    <dhcp>
      <range start='192.168.100.2' end='192.168.100.254'/>
    </dhcp>
  </ip>
</network>
EOF

virsh net-define /tmp/bridge.xml 2>/dev/null || true
virsh net-start br0 2>/dev/null || true
virsh net-autostart br0 2>/dev/null || true

log_info "================================"
log_info "Homelab Setup Complete!"
log_info "================================"
echo ""
log_info "VM Management Options:"
echo "  1. Desktop App: Launch 'Virtual Machine Manager' from applications"
echo "  2. Web UI: Open browser → http://localhost:9090"
echo "     Login with your Ubuntu username/password"
echo ""
log_info "Next Steps:"
echo "  - Log out and back in (for group changes)"
echo "  - Download Ubuntu Server ISO for VMs"
echo "  - Create your first VM!"
echo ""
log_info "Your user ($REAL_USER) is now in libvirt and kvm groups"
