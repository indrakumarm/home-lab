# Ubuntu Homelab Setup - Complete Guide

**Author:** Setup Guide  
**Date:** February 8, 2026  
**Version:** 1.0

---

## Table of Contents

1. [Introduction](#introduction)
2. [System Overview](#system-overview)
3. [Ubuntu Installation](#ubuntu-installation)
4. [Disk Partitioning](#disk-partitioning)
5. [Post-Installation Setup](#post-installation-setup)
6. [KVM Setup Scripts](#kvm-setup-scripts)
7. [VM Management](#vm-management)
8. [Development Environment](#development-environment)
9. [SSH Server Configuration](#ssh-server-configuration)
10. [Modular Setup Scripts](#modular-setup-scripts)
11. [Quick Reference](#quick-reference)

---

## 1. Introduction

This guide provides a complete setup for a production-grade Ubuntu homelab system that supports:

- **Development work** (Python coding, web development, etc.)
- **Virtual machines** for production services (web hosting, Git server, sandboxing)
- **SSH server** for remote access
- **Modular configuration** for easy system setup and maintenance

### System Specifications

- **Hardware:** 1TB (931GB) disk
- **Operating System:** Ubuntu 24.04 LTS (Long Term Support)
- **Virtualization:** KVM/QEMU
- **Support Period:** Until April 2029 (5 years)

---

## 2. System Overview

### What is LTS?

**LTS = Long Term Support**

- **Security updates** for 5 years
- **Bug fixes** for 5 years
- **Stability** - thoroughly tested before release
- **Ubuntu 24.04 LTS** - supported until April 2029

### LTS vs Non-LTS

| Version Type | Support Period | Best For |
|--------------|----------------|----------|
| LTS (24.04) | 5 years | Daily use, production, stability |
| Non-LTS (24.10) | 9 months | Testing, bleeding-edge features |

**Recommendation:** Always choose LTS for production systems.

### Architecture

```
Ubuntu 24.04 Desktop (Host Machine)
├─ Development Environment
│  ├─ Python, VS Code, Git
│  └─ Web browsers, tools
│
└─ KVM/QEMU (Virtualization)
   ├─ VM 1: Web Server (Nginx/Apache)
   ├─ VM 2: Git Server (GitLab/Gitea)
   └─ VM 3: Sandbox/Testing Environment
```

---

## 3. Ubuntu Installation

### Step 1: Download Ubuntu 24.04 LTS

1. Visit: https://ubuntu.com/download/desktop
2. Download **Ubuntu 24.04.1 LTS** (approximately 5-6GB)

### Step 2: Create Bootable USB

**Requirements:** USB drive with 8GB+ capacity

#### Option A: Using Rufus (Windows)
1. Download Rufus from https://rufus.ie/
2. Insert USB drive
3. Open Rufus
4. Select Ubuntu ISO file
5. Click START

#### Option B: Using dd (Linux)
```bash
# Insert USB and find device name
lsblk

# Create bootable USB (replace sdX with your USB device)
sudo dd if=ubuntu-24.04.1-desktop-amd64.iso of=/dev/sdX bs=4M status=progress && sync
```

#### Option C: Using Balena Etcher (Any OS)
1. Download from https://etcher.balena.io/
2. Select ISO file
3. Select USB drive
4. Flash

### Step 3: Boot from USB

1. Insert USB drive into computer
2. Restart computer
3. Press boot menu key during startup:
   - **F12** (most common)
   - **F2** or **Del** (some systems)
   - **Esc** (HP systems)
4. Select USB drive from boot menu
5. Choose "Try or Install Ubuntu"

### Step 4: Installation Process

1. **Language Selection:** Choose English (or preferred language)
2. **Installation Type:** Click "Install Ubuntu"
3. **Keyboard Layout:** Select your keyboard layout
4. **Updates and Software:**
   - ✅ Normal installation
   - ✅ Download updates while installing
   - ✅ Install third-party software (for graphics and Wi-Fi drivers)

---

## 4. Disk Partitioning

### Your Current Disk

```
Device: /dev/sda
Total Size: 931.5GB (1TB)
```

### Recommended Partition Scheme

For a homelab system running VMs and development work:

```
/dev/sda (931GB Total)

├─ /dev/sda1    512MB      EFI System Partition
├─ /dev/sda2    80GB       / (root) - Ubuntu OS
├─ /dev/sda3    100GB      /home - User files & code
├─ /dev/sda4    735GB      /vmstorage - VM virtual disks
└─ /dev/sda5    16GB       swap - Memory swap space
```

### Partition Details

| Partition | Size | Mount Point | Format | Purpose |
|-----------|------|-------------|--------|---------|
| sda1 | 512MB | /boot/efi | EFI | Boot partition |
| sda2 | 80GB | / | ext4 | Operating system |
| sda3 | 100GB | /home | ext4 | User files, projects, code |
| sda4 | 735GB | /vmstorage | ext4 | Virtual machine storage |
| sda5 | 16GB | swap | swap | Memory swap |

### Manual Partitioning During Installation

1. At "Installation type" screen, select **"Something else"**
2. Delete all existing partitions (you don't need the data)
3. Create new partitions as shown above:

**Creating EFI Partition:**
- Size: 512 MB
- Type: EFI System Partition
- Location: Beginning of this space

**Creating Root Partition:**
- Size: 80000 MB
- Type: ext4 journaling file system
- Mount point: /
- Location: Beginning of this space

**Creating Home Partition:**
- Size: 100000 MB
- Type: ext4 journaling file system
- Mount point: /home
- Location: Beginning of this space

**Creating VM Storage Partition:**
- Size: 735000 MB (or remaining space)
- Type: ext4 journaling file system
- Mount point: /vmstorage
- Location: Beginning of this space

**Creating Swap Partition:**
- Size: 16000 MB
- Type: swap area
- Location: Beginning of this space

4. Select /dev/sda1 for bootloader installation
5. Click "Install Now"
6. Confirm changes

### Step 5: Complete Setup

1. **Select Timezone:** Bangalore/Kolkata (or your location)
2. **Create User Account:**
   - Your name
   - Computer name (hostname)
   - Username
   - Password
3. **Wait for Installation:** 15-30 minutes
4. **Restart:** Click "Restart Now" when prompted
5. **Remove USB:** When prompted, remove USB drive and press Enter

---

## 5. Post-Installation Setup

### First Boot

1. Complete online accounts setup (or skip)
2. Skip or enable Ubuntu Pro (free for personal use)
3. Configure privacy settings
4. System is ready!

### Initial System Update

```bash
# Update package lists
sudo apt update

# Upgrade all packages
sudo apt upgrade -y

# Remove unnecessary packages
sudo apt autoremove -y
```

### Install Essential Tools

```bash
sudo apt install -y \
    curl \
    wget \
    git \
    vim \
    htop \
    build-essential \
    net-tools
```

---

## 6. KVM Setup Scripts

### Homelab Setup Script

Save this script as `homelab-setup.sh`:

```bash
#!/bin/bash

# Homelab Setup Script - Ubuntu + KVM
# For development + production VMs

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_step() { echo -e "${BLUE}[STEP]${NC} $1"; }

# Check root
if [[ $EUID -ne 0 ]]; then
    echo "Run with sudo"
    exit 1
fi

log_step "1/6 - Updating System"
apt update
apt upgrade -y

log_step "2/6 - Installing KVM/QEMU"
apt install -y \
    qemu-kvm \
    libvirt-daemon-system \
    libvirt-clients \
    bridge-utils \
    virt-manager \
    ovmf

log_step "3/6 - Installing Cockpit (Web UI for VM management)"
apt install -y cockpit cockpit-machines

log_step "4/6 - Installing Development Tools"
apt install -y \
    git \
    curl \
    wget \
    vim \
    build-essential \
    python3 \
    python3-pip \
    python3-venv \
    htop \
    net-tools

log_step "5/6 - Configuring KVM"

# Add user to groups
REAL_USER=${SUDO_USER:-$USER}
usermod -aG libvirt $REAL_USER
usermod -aG kvm $REAL_USER

# Enable services
systemctl enable libvirtd
systemctl start libvirtd
systemctl enable cockpit.socket
systemctl start cockpit.socket

# Configure VM storage pool
if [ -d "/vmstorage" ]; then
    log_info "Setting up VM storage at /vmstorage"
    mkdir -p /vmstorage/vms
    chown -R libvirt-qemu:kvm /vmstorage/vms
    
    # Create storage pool
    virsh pool-define-as vm-pool dir - - - - "/vmstorage/vms" 2>/dev/null || true
    virsh pool-build vm-pool 2>/dev/null || true
    virsh pool-start vm-pool 2>/dev/null || true
    virsh pool-autostart vm-pool 2>/dev/null || true
else
    log_info "Using default storage at /var/lib/libvirt/images"
fi

log_step "6/6 - Configuring Network Bridge (for VMs)"
# Create bridge network for VMs
cat > /tmp/bridge.xml << 'EOF'
<network>
  <name>br0</name>
  <forward mode='nat'>
    <nat>
      <port start='1024' end='65535'/>
    </nat>
  </forward>
  <bridge name='br0' stp='on' delay='0'/>
  <ip address='192.168.100.1' netmask='255.255.255.0'>
    <dhcp>
      <range start='192.168.100.2' end='192.168.100.254'/>
    </dhcp>
  </ip>
</network>
EOF

virsh net-define /tmp/bridge.xml 2>/dev/null || true
virsh net-start br0 2>/dev/null || true
virsh net-autostart br0 2>/dev/null || true

log_info "================================"
log_info "Homelab Setup Complete!"
log_info "================================"
echo ""
log_info "VM Management Options:"
echo "  1. Desktop App: Launch 'Virtual Machine Manager' from applications"
echo "  2. Web UI: Open browser → http://localhost:9090"
echo "     Login with your Ubuntu username/password"
echo ""
log_info "Next Steps:"
echo "  - Log out and back in (for group changes)"
echo "  - Download Ubuntu Server ISO for VMs"
echo "  - Create your first VM!"
echo ""
log_info "Your user ($REAL_USER) is now in libvirt and kvm groups"
```

### Make Script Executable

```bash
chmod +x homelab-setup.sh
```

### Run the Script

```bash
sudo ./homelab-setup.sh
```

### After Running Script

**Important:** Log out and log back in for group changes to take effect.

---

## 7. VM Management

### KVM Management Tools

#### 1. virt-manager (Desktop GUI)
- Graphical application
- Similar to VirtualBox interface
- Create and manage VMs with point-and-click
- Access: Applications → Virtual Machine Manager

#### 2. Cockpit (Web UI)
- Browser-based interface
- Access: http://localhost:9090
- Login with Ubuntu username/password
- Modern, clean interface

#### 3. virsh (Command Line)
- Terminal-based management
- For automation and scripting
- Full control over VMs

### Creating Your First VM

#### Method 1: Using virt-manager

1. Open "Virtual Machine Manager"
2. Click "Create a new virtual machine"
3. Select "Local install media (ISO image)"
4. Browse and select Ubuntu Server ISO
5. Set memory: 2-4 GB
6. Set disk size: 50 GB
7. Set network: br0 (bridge network)
8. Click "Finish" to start installation

#### Method 2: Using Cockpit

1. Open browser: http://localhost:9090
2. Navigate to "Virtual Machines"
3. Click "Create VM"
4. Follow the wizard:
   - Name: webserver
   - Installation source: Local ISO
   - Memory: 4096 MB
   - Storage: 50 GB
   - Network: Bridge to br0

#### Method 3: Command Line

```bash
# Download Ubuntu Server ISO
wget https://releases.ubuntu.com/24.04/ubuntu-24.04.1-live-server-amd64.iso

# Create VM
virt-install \
  --name=webserver \
  --ram=4096 \
  --vcpus=2 \
  --disk path=/vmstorage/vms/webserver.qcow2,size=50 \
  --network network=br0 \
  --graphics vnc \
  --cdrom=ubuntu-24.04.1-live-server-amd64.iso
```

### VM Network Configuration

VMs will receive IP addresses in the **192.168.100.x** range:
- Gateway: 192.168.100.1
- DHCP range: 192.168.100.2 - 192.168.100.254

### Accessing VMs from Host

```bash
# SSH to VM
ssh username@192.168.100.10

# Access web service running in VM
curl http://192.168.100.10:80

# Or open in browser
firefox http://192.168.100.10
```

### Common virsh Commands

```bash
# List all VMs
virsh list --all

# Start a VM
virsh start vm-name

# Shutdown VM gracefully
virsh shutdown vm-name

# Force stop VM
virsh destroy vm-name

# Delete VM (does not delete disk)
virsh undefine vm-name

# Delete VM disk
rm /vmstorage/vms/vm-name.qcow2

# Get VM information
virsh dominfo vm-name

# Connect to VM console
virsh console vm-name

# Take snapshot
virsh snapshot-create-as vm-name snapshot1

# List snapshots
virsh snapshot-list vm-name

# Restore snapshot
virsh snapshot-revert vm-name snapshot1
```

### Recommended VM Templates

#### Web Server VM
- **OS:** Ubuntu Server 24.04
- **RAM:** 2 GB
- **Disk:** 50 GB
- **Software:** Nginx or Apache, PHP/Node.js
- **Purpose:** Host websites and web applications

#### Git Server VM
- **OS:** Ubuntu Server 24.04
- **RAM:** 4 GB
- **Disk:** 100 GB
- **Software:** GitLab CE or Gitea
- **Purpose:** Private Git repository hosting

#### Sandbox/Testing VM
- **OS:** Ubuntu Desktop 24.04 (or any distribution)
- **RAM:** 4 GB
- **Disk:** 50 GB
- **Purpose:** Experimentation, testing, learning

---

## 8. Development Environment

### Setting Up Python Development

```bash
# Python is pre-installed in Ubuntu 24.04
python3 --version

# Install pip and venv
sudo apt install -y python3-pip python3-venv

# Install development tools
pip install --user virtualenv black pylint pytest
```

### Installing VS Code

```bash
# Install via Snap
sudo snap install code --classic

# Or download .deb from microsoft.com
```

### Creating a Python Project

```bash
# Create project directory
mkdir -p ~/projects/myapp
cd ~/projects/myapp

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Install packages
pip install flask requests

# Create requirements file
pip freeze > requirements.txt
```

### Installing Other Development Tools

```bash
# Node.js and npm
sudo apt install -y nodejs npm

# Docker (optional)
sudo apt install -y docker.io
sudo usermod -aG docker $USER

# Database tools
sudo apt install -y postgresql postgresql-contrib
sudo apt install -y mysql-server
```

---

## 9. SSH Server Configuration

### Installing SSH Server

```bash
# Install OpenSSH Server
sudo apt update
sudo apt install -y openssh-server

# Check status
sudo systemctl status ssh

# Enable on boot
sudo systemctl enable ssh

# Start service
sudo systemctl start ssh
```

### Basic SSH Configuration

The main configuration file is located at: `/etc/ssh/sshd_config`

#### Recommended Security Settings

```bash
# Backup original config
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.backup

# Edit configuration
sudo nano /etc/ssh/sshd_config
```

**Recommended changes:**

```
# Change default port (optional, for security)
Port 22

# Disable root login
PermitRootLogin no

# Use SSH keys (after setting them up)
PubkeyAuthentication yes

# Disable password authentication (after setting up keys)
# PasswordAuthentication no

# Limit authentication attempts
MaxAuthTries 3

# Set login grace time
LoginGraceTime 60
```

#### Apply Changes

```bash
# Test configuration
sudo sshd -t

# Restart SSH service
sudo systemctl restart ssh
```

### Configuring Firewall

```bash
# Install ufw if not present
sudo apt install -y ufw

# Allow SSH
sudo ufw allow ssh
# Or specific port if changed
sudo ufw allow 2222/tcp

# Enable firewall
sudo ufw enable

# Check status
sudo ufw status
```

### Finding Your IP Address

```bash
# Show all network interfaces
ip a

# Show just IP addresses
hostname -I

# Get primary IP
hostname -I | awk '{print $1}'
```

### Connecting via SSH

From another computer:

```bash
ssh username@192.168.1.100
```

Replace `username` with your Ubuntu username and `192.168.1.100` with your actual IP address.

---

## 10. Modular Setup Scripts

### Directory Structure

```
system-setup/
├── setup.sh              # Main orchestration script
├── modules/              # Individual setup modules
│   ├── ssh.sh           # SSH server setup
│   ├── docker.sh        # Docker installation
│   ├── tools.sh         # Development tools
│   ├── security.sh      # Security hardening
│   └── nginx.sh         # Web server (example)
├── configs/              # Configuration files
│   ├── sshd_config      # Custom SSH config
│   └── .bashrc          # Bash customizations
└── README.md            # Documentation
```

### Main Setup Script

Save as `system-setup/setup.sh`:

```bash
#!/bin/bash

# Main System Setup Script
# Usage: sudo ./setup.sh [module1] [module2] ...
# Example: sudo ./setup.sh ssh docker
# If no modules specified, runs all

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODULES_DIR="$SCRIPT_DIR/modules"
CONFIGS_DIR="$SCRIPT_DIR/configs"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_module() { echo -e "${BLUE}[MODULE]${NC} $1"; }

# Check if running as root
if [[ $EUID -ne 0 ]]; then
    log_error "This script must be run as root (use sudo)"
    exit 1
fi

# Available modules
declare -A MODULES=(
    [ssh]="SSH Server"
    [docker]="Docker & Docker Compose"
    [tools]="Development Tools"
    [security]="Security Hardening"
)

# Show available modules
show_modules() {
    log_info "Available modules:"
    for key in "${!MODULES[@]}"; do
        echo "  - $key: ${MODULES[$key]}"
    done
}

# Run a specific module
run_module() {
    local module=$1
    local module_file="$MODULES_DIR/${module}.sh"
    
    if [ -f "$module_file" ]; then
        log_module "Running module: ${MODULES[$module]}"
        source "$module_file"
    else
        log_error "Module not found: $module"
        return 1
    fi
}

# Main
main() {
    log_info "System Setup Starting..."
    echo ""
    
    # If no arguments, show available modules and prompt
    if [ $# -eq 0 ]; then
        show_modules
        echo ""
        read -p "Enter modules to install (space-separated, or 'all'): " -a selected_modules
        
        if [ "${selected_modules[0]}" == "all" ]; then
            selected_modules=("${!MODULES[@]}")
        fi
    else
        selected_modules=("$@")
    fi
    
    # Run selected modules
    for module in "${selected_modules[@]}"; do
        if [ -n "${MODULES[$module]}" ]; then
            run_module "$module"
        else
            log_error "Unknown module: $module"
        fi
    done
    
    log_info "Setup complete!"
}

main "$@"
```

### SSH Module

Save as `system-setup/modules/ssh.sh`:

```bash
#!/bin/bash

# SSH Server Setup Module

setup_ssh() {
    log_info "Installing OpenSSH Server..."
    
    apt update
    apt install -y openssh-server
    
    log_info "Enabling SSH service..."
    systemctl enable ssh
    systemctl start ssh
    
    # Backup original config
    if [ ! -f /etc/ssh/sshd_config.backup ]; then
        cp /etc/ssh/sshd_config /etc/ssh/sshd_config.backup
        log_info "Created backup: /etc/ssh/sshd_config.backup"
    fi
    
    # Apply custom config if exists
    if [ -f "$CONFIGS_DIR/sshd_config" ]; then
        log_info "Applying custom SSH configuration..."
        cp "$CONFIGS_DIR/sshd_config" /etc/ssh/sshd_config
        systemctl restart ssh
    fi
    
    # Configure firewall
    if command -v ufw &> /dev/null; then
        log_info "Configuring firewall..."
        ufw allow ssh
    fi
    
    # Display server IP
    log_info "SSH Server is running!"
    echo -e "  IP Address: $(hostname -I | awk '{print $1}')"
    echo -e "  Connect with: ssh $(whoami)@$(hostname -I | awk '{print $1}')"
}

# Run the setup
setup_ssh
```

### Docker Module

Save as `system-setup/modules/docker.sh`:

```bash
#!/bin/bash

# Docker Setup Module

setup_docker() {
    log_info "Installing Docker..."
    
    # Remove old versions
    apt remove -y docker docker-engine docker.io containerd runc 2>/dev/null || true
    
    # Install prerequisites
    apt install -y \
        ca-certificates \
        curl \
        gnupg \
        lsb-release
    
    # Add Docker's official GPG key
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    
    # Set up repository
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
      $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # Install Docker Engine
    apt update
    apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    
    # Enable Docker service
    systemctl enable docker
    systemctl start docker
    
    # Add current user to docker group (if not root)
    if [ -n "$SUDO_USER" ]; then
        usermod -aG docker "$SUDO_USER"
        log_info "Added $SUDO_USER to docker group (logout/login required)"
    fi
    
    log_info "Docker installed successfully!"
    docker --version
}

setup_docker
```

### Development Tools Module

Save as `system-setup/modules/tools.sh`:

```bash
#!/bin/bash

# Development Tools Setup Module

setup_tools() {
    log_info "Installing development tools..."
    
    apt update
    apt install -y \
        git \
        curl \
        wget \
        vim \
        htop \
        tree \
        tmux \
        build-essential \
        software-properties-common \
        net-tools \
        ufw \
        python3 \
        python3-pip \
        python3-venv
    
    log_info "Development tools installed successfully!"
}

setup_tools
```

### Security Module

Save as `system-setup/modules/security.sh`:

```bash
#!/bin/bash

# Security Hardening Module

setup_security() {
    log_info "Applying security hardening..."
    
    # Enable UFW firewall
    if command -v ufw &> /dev/null; then
        log_info "Configuring UFW firewall..."
        ufw --force enable
        ufw default deny incoming
        ufw default allow outgoing
        log_info "Firewall configured (default deny incoming)"
    fi
    
    # Install fail2ban
    log_info "Installing fail2ban..."
    apt install -y fail2ban
    systemctl enable fail2ban
    systemctl start fail2ban
    
    # Configure automatic security updates
    log_info "Setting up automatic security updates..."
    apt install -y unattended-upgrades
    dpkg-reconfigure -plow unattended-upgrades
    
    log_info "Security hardening complete!"
}

setup_security
```

### Custom SSH Configuration File

Save as `system-setup/configs/sshd_config`:

```
# Custom SSH Server Configuration
# Security-focused settings

# Network
Port 22
AddressFamily any
ListenAddress 0.0.0.0

# Security
PermitRootLogin no
PasswordAuthentication yes
PubkeyAuthentication yes
PermitEmptyPasswords no
ChallengeResponseAuthentication no

# Authentication
MaxAuthTries 3
MaxSessions 10
LoginGraceTime 60

# Protocol
Protocol 2
HostKey /etc/ssh/ssh_host_rsa_key
HostKey /etc/ssh/ssh_host_ecdsa_key
HostKey /etc/ssh/ssh_host_ed25519_key

# Logging
SyslogFacility AUTH
LogLevel INFO

# Features
UsePAM yes
X11Forwarding yes
PrintMotd no
AcceptEnv LANG LC_*

# Subsystems
Subsystem sftp /usr/lib/openssh/sftp-server
```

### Usage Examples

```bash
# Make script executable
chmod +x setup.sh
chmod +x modules/*.sh

# Install all modules
sudo ./setup.sh all

# Install specific modules
sudo ./setup.sh ssh docker

# Interactive mode
sudo ./setup.sh
```

### Adding New Modules

1. Create new file: `modules/mymodule.sh`
2. Add setup function
3. Register in main `setup.sh` MODULES array
4. Make executable: `chmod +x modules/mymodule.sh`

---

## 11. Quick Reference

### Common Commands

#### System Management
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Check disk usage
df -h

# Check memory usage
free -h

# Monitor system resources
htop

# Check running services
systemctl list-units --type=service
```

#### KVM/VM Management
```bash
# List VMs
virsh list --all

# Start VM
virsh start vm-name

# Stop VM
virsh shutdown vm-name

# Delete VM
virsh undefine vm-name

# VM info
virsh dominfo vm-name
```

#### SSH
```bash
# Check SSH status
sudo systemctl status ssh

# Restart SSH
sudo systemctl restart ssh

# View SSH logs
sudo journalctl -u ssh -n 50

# Test SSH config
sudo sshd -t
```

#### Firewall (UFW)
```bash
# Enable firewall
sudo ufw enable

# Allow service
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Check status
sudo ufw status verbose

# Disable firewall
sudo ufw disable
```

### File Locations

| Item | Location |
|------|----------|
| SSH config | `/etc/ssh/sshd_config` |
| VM storage | `/vmstorage/vms/` |
| User files | `/home/username/` |
| VM config | `/etc/libvirt/qemu/` |
| System logs | `/var/log/` |

### Port Reference

| Service | Default Port |
|---------|--------------|
| SSH | 22 |
| HTTP | 80 |
| HTTPS | 443 |
| Cockpit | 9090 |
| MySQL | 3306 |
| PostgreSQL | 5432 |

### Performance Tips

1. **Don't over-allocate VM resources** - Leave at least 4GB RAM for host
2. **Use virtio drivers** - Automatic in modern Linux VMs
3. **Use qcow2 disk format** - Supports snapshots and thin provisioning
4. **Regular backups** - Use VM snapshots before major changes
5. **Monitor resources** - Use htop to watch CPU, RAM, disk I/O

### Troubleshooting

#### VMs Won't Start
```bash
# Check libvirtd service
sudo systemctl status libvirtd

# Check logs
sudo journalctl -u libvirtd -n 50

# Restart service
sudo systemctl restart libvirtd
```

#### Can't Create VMs
```bash
# Verify group membership
groups $USER

# Should show: libvirt kvm
# If not, log out and back in

# Check storage pool
virsh pool-list --all
virsh pool-start vm-pool
```

#### Network Issues in VMs
```bash
# Check network
virsh net-list --all

# Start network
virsh net-start br0

# Restart network
virsh net-destroy br0
virsh net-start br0
```

#### Cockpit Won't Open
```bash
# Check status
sudo systemctl status cockpit.socket

# Restart
sudo systemctl restart cockpit.socket

# Access in browser
http://localhost:9090
```

---

## Appendix: Why Ubuntu + KVM vs Other Options

### Comparison Matrix

| Solution | Development | VM Performance | Ease of Use | Production Ready |
|----------|-------------|----------------|-------------|------------------|
| **Ubuntu + KVM** | ✅ Excellent | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ✅ Yes |
| Proxmox VE | ❌ No Desktop | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ Yes |
| Ubuntu + VirtualBox | ✅ Yes | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| Windows + Hyper-V | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |

### Why We Chose Ubuntu + KVM

1. **Best of Both Worlds**
   - Full desktop environment for development
   - Professional virtualization for production VMs
   - Single system, no dual-boot needed

2. **Performance**
   - KVM is built into Linux kernel
   - Native performance, minimal overhead
   - Better than VirtualBox for production use

3. **Management Options**
   - virt-manager: Desktop GUI
   - Cockpit: Web interface
   - virsh: Command line
   - Choose what fits your workflow

4. **Production Ready**
   - Used in enterprise environments
   - Reliable and stable
   - Well-documented and supported

5. **Future-Proof**
   - Can add more features later
   - Supports clustering (if you add more machines)
   - Compatible with industry standards

---

## Summary

This guide provides everything needed to set up a complete Ubuntu homelab system that serves dual purposes:

1. **Development Machine**: Python coding, web development, and general computing
2. **VM Host**: Running production services in isolated virtual machines

### Key Takeaways

- **Use Ubuntu 24.04 LTS** for 5 years of support
- **Partition wisely** with separate space for VMs
- **KVM provides** near-native performance for VMs
- **Modular scripts** make system setup reproducible
- **Multiple management tools** (GUI, Web, CLI) for flexibility

### Next Steps After Setup

1. Log out and back in after running homelab-setup.sh
2. Download Ubuntu Server ISO for creating VMs
3. Create your first VM (web server, git server, or sandbox)
4. Start developing and hosting services!

---

**End of Document**
