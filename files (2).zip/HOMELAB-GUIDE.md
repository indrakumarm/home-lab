# Homelab Setup - Quick Reference Guide

## Your System Setup

```
Ubuntu 24.04 Desktop (Host Machine)
├─ Development Environment (Python, coding, etc.)
└─ KVM/QEMU (Running production VMs)
    ├─ VM 1: Web Server
    ├─ VM 2: Git Server (GitLab/Gitea)
    └─ VM 3: Sandbox/Testing
```

## Disk Partitioning Scheme

```
/dev/sda (931GB Total)
├─ /boot/efi      512MB    Boot partition
├─ /              80GB     Ubuntu OS
├─ /home          100GB    Your files & code
├─ /vmstorage     735GB    VM virtual disks
└─ swap           16GB     Swap partition
```

## After Fresh Ubuntu Install

1. **Run the homelab setup script:**
   ```bash
   chmod +x homelab-setup.sh
   sudo ./homelab-setup.sh
   ```

2. **Log out and back in** (for group permissions)

3. **Access VM management:**
   - Desktop: Open "Virtual Machine Manager"
   - Web UI: http://localhost:9090

## Creating Your First VM

### Method 1: Using virt-manager (GUI)

1. Open "Virtual Machine Manager"
2. Click "Create a new virtual machine"
3. Choose ISO (download Ubuntu Server 24.04)
4. Set RAM: 2-4GB
5. Set Disk: 50GB
6. Set Network: br0 (bridge)
7. Install!

### Method 2: Using Cockpit (Web UI)

1. Open browser → http://localhost:9090
2. Login with your Ubuntu username
3. Go to "Virtual Machines"
4. Click "Create VM"
5. Follow wizard

### Method 3: Command Line (Advanced)

```bash
# Download Ubuntu Server ISO
wget https://releases.ubuntu.com/24.04/ubuntu-24.04.1-live-server-amd64.iso

# Create VM
virt-install \
  --name=webserver \
  --ram=4096 \
  --vcpus=2 \
  --disk path=/vmstorage/vms/webserver.qcow2,size=50 \
  --network network=br0 \
  --graphics vnc \
  --cdrom=ubuntu-24.04.1-live-server-amd64.iso
```

## Useful KVM Commands

```bash
# List all VMs
virsh list --all

# Start a VM
virsh start vm-name

# Stop a VM
virsh shutdown vm-name

# Force stop
virsh destroy vm-name

# Delete a VM
virsh undefine vm-name
rm /vmstorage/vms/vm-name.qcow2

# VM info
virsh dominfo vm-name

# Connect to VM console
virsh console vm-name
```

## Development Setup on Host

```bash
# Install VS Code
sudo snap install code --classic

# Install Python tools
pip install --user virtualenv black pylint pytest

# Create project
mkdir ~/projects/myapp
cd ~/projects/myapp
python3 -m venv venv
source venv/bin/activate
```

## VM Network Configuration

Your VMs will get IPs in `192.168.100.x` range:
- Gateway: 192.168.100.1
- VM IPs: 192.168.100.2 - 192.168.100.254

To access VMs from host:
```bash
# SSH to VM
ssh user@192.168.100.10

# Access web service
curl http://192.168.100.10:80
```

## Recommended VM Templates

### Web Server VM
- OS: Ubuntu Server 24.04
- RAM: 2GB
- Disk: 50GB
- Software: Nginx/Apache, PHP/Node.js

### Git Server VM
- OS: Ubuntu Server 24.04
- RAM: 4GB
- Disk: 100GB
- Software: GitLab CE or Gitea

### Sandbox VM
- OS: Ubuntu Desktop 24.04 (or any distro)
- RAM: 4GB
- Disk: 50GB
- Purpose: Testing, experiments

## Performance Tips

1. **Use virtio drivers** (automatic in modern Linux VMs)
2. **Use qcow2 format** for disk images (supports snapshots)
3. **Don't over-allocate RAM** - leave some for host
4. **Monitor resources** with `htop` on host

## Backup VMs

```bash
# Snapshot a VM (instant)
virsh snapshot-create-as vm-name snapshot1

# List snapshots
virsh snapshot-list vm-name

# Restore snapshot
virsh snapshot-revert vm-name snapshot1

# Export/backup VM disk
cp /vmstorage/vms/vm-name.qcow2 /backup/
```

## Troubleshooting

**Can't create VMs:**
- Check: `sudo systemctl status libvirtd`
- Check groups: `groups $USER` (should show libvirt, kvm)
- Re-login if just ran setup

**VMs have no network:**
- Check: `virsh net-list --all`
- Start network: `virsh net-start br0`

**Cockpit won't open:**
- Check: `sudo systemctl status cockpit.socket`
- Restart: `sudo systemctl restart cockpit.socket`

## Resources

- VM ISOs: https://ubuntu.com/download/server
- KVM docs: https://linux-kvm.org/
- Cockpit: https://cockpit-project.org/
- Libvirt: https://libvirt.org/
